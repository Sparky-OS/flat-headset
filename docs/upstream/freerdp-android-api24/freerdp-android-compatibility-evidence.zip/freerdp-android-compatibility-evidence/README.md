# Android embedding compatibility reproducer

Base: FreeRDP master 9f9d97e81cc59f63a3f8c07e3b1d3a4f9b7fc3d4.
The production commits do not change the default SDK requirements.

For the compatibility experiment, use the project's client/Android/Studio Gradle wrapper with SDK 37, Build Tools 37.0.0, NDK 29.0.13113456 and CMake 4.1.2.
Copy the included release.properties into client/Android/Studio; it selects x86_64 and MIN_API=24.
The complete five-commit patch is upstream-m4-series.patch; apply with git am to the base revision for the candidate, or leave the base unchanged for the control.
The print-file test uses TARGET_API=28 to exercise legacy shared Download access on the old emulator images.
It writes and closes a PDF with the production rdp_print_ prefix, checks the notification, and removes its own files.

The debug harness adds an instrumentation entry without replacing the production Application or library.
Provide HARNESS_DIR pointing at this attachment and PUBLIC_DEBUG_KEY pointing at Flat Headset's documented public android/debug.keystore.
Build from client/Android/Studio (JDK 17). Keep the native make calls bounded by running `chmod +x "$HARNESS_DIR/build-bin/make"` and placing build-bin/make on PATH and setting CMAKE_BUILD_PARALLEL_LEVEL=4:

```
./gradlew --no-daemon --max-workers=2 -I "$HARNESS_DIR/harness.gradle" :freeRDPCore:assembleDebug :aFreeRDP:assembleDebug
```

Install only into a disposable x86_64 emulator, grant READ_EXTERNAL_STORAGE and WRITE_EXTERNAL_STORAGE and create /sdcard/Download before starting the app.
Run each mode in a fresh application process:

```
adb shell am force-stop com.freerdp.afreerdp
adb shell am instrument -w -r -e mode startup com.freerdp.afreerdp/com.freerdp.afreerdp.proof.CompatibilityInstrumentation
```

Other modes: print, parcel, input, save, session.
Save requires `-e server SERVER_IP` for the isolated RDP fixture at port 3389.
Save and session must run in separate processes so the reload comes from the database.
The fixture uses the public dummy username/password fixture, explicit RDP security, no authentication, and no host-published ports.
The session test expects a 2400x1080 desktop with paired markers at (32,32) and (1232,32), green=96, blue=32/224 and matching changing red values.
A passing instrument run has INSTRUMENTATION_CODE: -1 and a PASS line, not just an adb exit status of zero.
The unpatched Application crashes before the harness can finish on API 24 and 28.

This is an embedding compatibility experiment, not a promise that every standalone aFreeRDP launcher or external-display feature supports API 24.
It does not test ARM, physical devices, stereo rendering or Flat Headset's custom HEVC negotiation.
Native dependency builds and Java builds use the upstream Gradle/CMake setup.


Measured results (x86_64, headless KVM/SwiftShader):

| Tree | API 24 | API 28 | API 29 |
|---|---|---|---|
| master | real Application crashes: FileObserver(File,int) | same crash | all six modes pass |
| first four commits | input and session construction fail at API-26 scroll factors | input fails at API-29 classification | not run |
| all five commits | all six modes pass | all six modes pass | all six modes pass |

Final disconnect times: master/API29 4513ms; candidate/API24 903ms, API28 2525ms, API29 6820ms.
The retained master-first-api29 case exceeded an initial 15-second disconnect deadline; the final identical harness uses 60 seconds and checks actual Activity destruction and zero remaining native sessions.
The final comparison uses that same harness on master and candidate.
Run `python3 check-runtime.py` from this attachment to verify its saved logs.
`checks/screenshot-check.txt` records the screenshot marker checks; the session harness also requires three changing decoded-frame values before disconnect.

To reproduce the fixture, use an isolated container with FreeRDP shadow server 3.10.3, Xvfb, x11-utils and Python Tk installed. Mount fixture/ at /proof and run `bash /proof/rdp-server.sh`.
The measured image content ID was sha256:929498277b20eb46f8de6c266bfb0eb309a24b3b12b70897f2f6c9a34b8a6fc6; it is a locally built test image, not a downloadable registry reference.
Use an internal Docker network shared only by this container and the emulator container, without published ports or an external route.
The emulator uses a 2400x1080 screen at density 320, two cores, 2048MB RAM and `-no-window -no-audio -gpu swiftshader -no-snapshot`; API24 additionally uses `-feature -GLDMA`.
Install with `adb install --no-streaming -r APK`, then run startup, print, save, parcel, input and session, force-stopping between modes.

Local style checks: `git clang-format --diff BASE` with clang-format 14.0.6 and `./scripts/codespell.sh` with codespell 2.4.1 both exit 0.
Codespell 2.2.2 and 2.4.3 identify pre-existing words elsewhere in the tree; their outputs are retained and are not claimed green.
Lint: `./gradlew -I "$HARNESS_DIR/newapi.gradle" :freeRDPCore:lintDebug` at the selected MIN_API=24 reports 50 NewApi findings on master and one on the final branch (ExternalDisplayManager.setLaunchDisplayId, in the standalone display-picker route).
The lint overlay deliberately disables abortOnError to collect diagnostics; exit 0 is not a clean lint result.
`:freeRDPCore:testDebugUnitTest` reports NO-SOURCE, not executed tests.
Full master and final native/Java build logs, five independent Java/AAR/APK build logs, signatures and APK hashes are included under checks/.
Independent checks exclude `:freeRDPCore:configureCMakeDebug[x86_64]` and `:freeRDPCore:buildCMakeDebug[x86_64]`, reusing native outputs whose sources are unchanged.

This attachment contains no APK or signing key. Obtain the public debug key from https://github.com/Sparky-OS/flat-headset/blob/34bfd5a/android/debug.keystore; no private release key is used.
Workstation paths in logs are replaced by $WORKSPACE, $BUILD_ROOT and $USER_HOME. Failed controls are retained alongside passing cases.
