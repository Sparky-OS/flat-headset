/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only OR LicenseRef-KDE-Accepted-GPL */
package com.freerdp.afreerdp.proof;

import android.app.*;
import android.content.*;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.*;
import com.freerdp.freerdpcore.application.GlobalApp;
import com.freerdp.freerdpcore.application.SessionState;
import com.freerdp.freerdpcore.data.AppDatabase;
import com.freerdp.freerdpcore.domain.BookmarkBase;
import com.freerdp.freerdpcore.domain.ConnectionReference;
import com.freerdp.freerdpcore.presentation.SessionActivity;
import com.freerdp.freerdpcore.services.ManualBookmarkGateway;
import java.io.*;
import java.lang.reflect.*;
import java.util.*;
import java.util.concurrent.*;

/** Private emulator harness. Production sources and Application are not replaced. */
public class CompatibilityInstrumentation extends Instrumentation {
    private final CountDownLatch created = new CountDownLatch(1);
    private Bundle arguments;
    private final StringBuilder proof = new StringBuilder();
    @Override public void onCreate(Bundle args) { super.onCreate(args); arguments = args; start(); }
    @Override public void callApplicationOnCreate(Application app) {
        super.callApplicationOnCreate(app);
        created.countDown();
    }
    private void require(boolean value, String message) {
        if (!value) throw new AssertionError(message);
    }
    @Override public void onStart() {
        Bundle result = new Bundle();
        try {
            require(created.await(30, TimeUnit.SECONDS), "Application.onCreate did not finish");
            require(getTargetContext().getApplicationContext().getClass().getName().equals(
                "com.freerdp.afreerdp.application.GlobalApp"), "real aFreeRDP Application");
            require(getTargetContext().getApplicationInfo().minSdkVersion == 24, "minSdk 24");
            String mode = arguments.getString("mode", "startup");
            switch (mode) {
                case "startup": break;
                case "print": checkPrint(); break;
                case "parcel": checkParcel(); break;
                case "input": checkInput(); break;
                case "save": saveBookmark(); break;
                case "session": checkSession(); break;
                default: throw new AssertionError("unknown mode " + mode);
            }
            result.putString("stream", proof + "PASS: real aFreeRDP Application API " + Build.VERSION.SDK_INT + " mode=" + mode + "\n");
            finish(Activity.RESULT_OK, result);
        } catch (Throwable error) {
            StringWriter trace = new StringWriter(); error.printStackTrace(new PrintWriter(trace));
            result.putString("stream", proof + trace.toString());
            finish(Activity.RESULT_CANCELED, result);
        }
    }
    private void checkPrint() throws Exception {
        NotificationManager manager = getTargetContext().getSystemService(NotificationManager.class);
        manager.cancelAll();
        Field monitor = GlobalApp.class.getDeclaredField("printJobMonitor"); monitor.setAccessible(true);
        require(monitor.get(getTargetContext().getApplicationContext()) != null, "production monitor");
        File dir = new File("/sdcard/Download");
        File ignored = new File(dir, "ignored_m4.pdf");
        File pdf = new File(dir, "rdp_print_m4_" + SystemClock.elapsedRealtime() + ".pdf");
        try {
            write(ignored, "ignored"); SystemClock.sleep(500);
            require(manager.getActiveNotifications().length == 0, "unrelated file ignored");
            write(pdf, "%PDF-1.4 proof");
            long end = SystemClock.elapsedRealtime() + 5000;
            while (manager.getActiveNotifications().length == 0 && SystemClock.elapsedRealtime() < end) SystemClock.sleep(50);
            require(manager.getActiveNotifications().length == 1, "one CLOSE_WRITE notification");
            Notification notification = manager.getActiveNotifications()[0].getNotification();
            require(pdf.getName().contentEquals(notification.extras.getCharSequence(Notification.EXTRA_TEXT)), "print filename");
            require(notification.contentIntent != null && notification.actions.length == 2, "open and print actions");
            if (Build.VERSION.SDK_INT >= 26) require("rdp_print".equals(notification.getChannelId()), "print channel");
            SystemClock.sleep(300);
            require(manager.getActiveNotifications().length == 1, "no duplicate");
            proof.append("print: production observer, unrelated file ignored, one notification with filename and actions\n");
        } finally { manager.cancelAll(); ignored.delete(); pdf.delete(); }
    }
    private void checkInput() throws Exception {
        java.util.concurrent.atomic.AtomicReference<Throwable> failure = new java.util.concurrent.atomic.AtomicReference<>();
        runOnMainSync(() -> {
            try {
                com.freerdp.freerdpcore.presentation.SessionView view = new com.freerdp.freerdpcore.presentation.SessionView(getTargetContext());
                for (String name : new String[] {"notchPxX", "notchPxY"}) {
                    Field f = view.getClass().getDeclaredField(name); f.setAccessible(true);
                    float value = f.getFloat(view); require(Float.isFinite(value) && value > 1, "theme scroll factor " + name);
                    proof.append(name + "=" + value + "\n");
                }
                com.freerdp.freerdpcore.presentation.ScrollView2D scroll = new com.freerdp.freerdpcore.presentation.ScrollView2D(getTargetContext());
                long now = SystemClock.uptimeMillis();
                android.view.MotionEvent event = android.view.MotionEvent.obtain(now, now, android.view.MotionEvent.ACTION_MOVE, 32, 32, 0);
                try {
                    scroll.onInterceptTouchEvent(event);
                    event.setSource(android.view.InputDevice.SOURCE_MOUSE);
                    require(view.onTouchEvent(event), "mouse event handled");
                } finally { event.recycle(); }
            } catch (Throwable error) { failure.set(error); }
        });
        if (failure.get() != null) throw new AssertionError("session view input API compatibility", failure.get());
        proof.append("session view construction, scroll interception and mouse input API paths passed\n");
    }
    private void write(File file, String text) throws IOException {
        try (FileWriter out = new FileWriter(file)) { out.write(text); }
    }
    private Object[] parts(BookmarkBase b) {
        return new Object[] {b, b.getPerformanceFlags(), b.getAdvancedSettings(), b.getDebugSettings()};
    }
    private void checkParcel() throws Exception {
        for (boolean invert : new boolean[] {false, true}) {
            BookmarkBase original = new BookmarkBase();
            original.setLabel("parcel fixture"); original.setHostname("192.0.2.1"); original.setPort(3390);
            int count = 0;
            for (Object part : parts(original)) {
                Field[] fields = part.getClass().getDeclaredFields();
                Arrays.sort(fields, Comparator.comparing(Field::getName));
                for (Field f : fields) if (f.getType() == boolean.class && !Modifier.isStatic(f.getModifiers())) {
                    f.setAccessible(true); f.setBoolean(part, (count++ % 2 == 0) ^ invert);
                }
            }
            require(count == 20, "expected 20 flags, found " + count);
            Parcel p = Parcel.obtain();
            try {
                original.writeToParcel(p, 0); byte[] bytes = p.marshall(); p.setDataPosition(0);
                BookmarkBase restored = BookmarkBase.CREATOR.createFromParcel(p);
                require(p.dataAvail() == 0, "no trailing parcel data");
                require(original.getLabel().equals(restored.getLabel()) && original.getHostname().equals(restored.getHostname()) && original.getPort() == restored.getPort(), "other fields unchanged");
                Object[] before = parts(original), after = parts(restored);
                for (int i=0; i<before.length; i++) for (Field f : before[i].getClass().getDeclaredFields())
                    if (f.getType() == boolean.class && !Modifier.isStatic(f.getModifiers())) {
                        f.setAccessible(true); require(f.getBoolean(before[i]) == f.getBoolean(after[i]), f.getName());
                    }
                StringBuilder digest = new StringBuilder();
                for (byte b : java.security.MessageDigest.getInstance("SHA-256").digest(bytes)) digest.append(String.format("%02x", b));
                proof.append("parcel invert=" + invert + " flags=" + count + " bytes=" + bytes.length + " sha256=" + digest + "\n");
            } finally { p.recycle(); }
        }
    }
    private ManualBookmarkGateway gateway() { return new ManualBookmarkGateway(AppDatabase.getInstance(getTargetContext()).bookmarkDao()); }
    private SharedPreferences preferences() { return getTargetContext().getSharedPreferences("m4-proof", Context.MODE_PRIVATE); }
    private void saveBookmark() {
        BookmarkBase b = new BookmarkBase(); String host = arguments.getString("server");
        require(host != null, "explicit isolated server required");
        b.setLabel("Isolated RDP proof"); b.setHostname(host); b.setPort(3389);
        b.setUsername("fixture"); b.setPassword("fixture");
        b.getDebugSettings().setDebugLevel("DEBUG");
        b.getScreenSettings().setResolution("custom", 2400, 1080); b.getScreenSettings().setColors(32);
        b.getAdvancedSettings().setSecurity(1); b.getAdvancedSettings().setRedirectSound(2);
        b.getAdvancedSettings().setRedirectMicrophone(false); b.getAdvancedSettings().setRedirectCamera(false);
        b.getAdvancedSettings().setRedirectPrinter(false); b.getAdvancedSettings().setRedirectSDCard(false);
        long id = gateway().insert(b); require(id > 0, "saved bookmark");
        require(gateway().findById(id).getHostname().equals(host), "database round trip");
        require(preferences().edit().putLong("bookmark", id).putString("server", host).commit(), "saved ID");
        proof.append("bookmark saved id=" + id + "; restart process before session\n");
    }
    private void checkSession() throws Exception {
        long id = preferences().getLong("bookmark", -1); require(id > 0, "saved bookmark ID");
        BookmarkBase b = gateway().findById(id);
        require(b != null && b.getHostname().equals(preferences().getString("server", "")), "bookmark reload after process restart");
        require(b.getScreenSettings().getWidth() == 2400 && b.getScreenSettings().getHeight() == 1080 && b.getAdvancedSettings().getSecurity() == 1, "saved session settings");
        proof.append("bookmark reloaded after process restart id=" + id + "\n");
        Intent intent = new Intent(getTargetContext(), SessionActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            .putExtra(SessionActivity.PARAM_CONNECTION_REFERENCE, ConnectionReference.getBookmarkReference(id));
        SessionActivity activity = (SessionActivity)startActivitySync(intent);
        long end = SystemClock.elapsedRealtime() + 45000;
        Set<Integer> reds = new HashSet<>();
        while (SystemClock.elapsedRealtime() < end && reds.size() < 3) {
            runOnMainSync(() -> {
                if (GlobalApp.getSessions().size() != 1) return;
                SessionState session = GlobalApp.getSessions().iterator().next();
                if (session.getSurface() == null) return;
                Bitmap bitmap = session.getSurface().getBitmap();
                if (bitmap == null || bitmap.getWidth() != 2400 || bitmap.getHeight() != 1080) return;
                int left = bitmap.getPixel(32,32), right = bitmap.getPixel(1232,32);
                if (Math.abs(Color.green(left)-96)<=4 && Math.abs(Color.blue(left)-32)<=4 &&
                    Math.abs(Color.green(right)-96)<=4 && Math.abs(Color.blue(right)-224)<=4 &&
                    Math.abs(Color.red(left)-Color.red(right))<=4) reds.add(Color.red(left));
            });
            SystemClock.sleep(100);
        }
        require(reds.size() >= 3, "three changing rendered RDP markers, got " + reds);
        proof.append("real RDP surface: 2400x1080 paired markers, changing red values=" + reds + "\n");
        Bitmap screenshot = getUiAutomation().takeScreenshot(); require(screenshot != null, "screenshot");
        try (FileOutputStream out = new FileOutputStream(new File(getTargetContext().getFilesDir(), "session-proof.png"))) {
            screenshot.compress(Bitmap.CompressFormat.PNG, 100, out);
        } finally { screenshot.recycle(); }
        runOnMainSync(() -> { activity.handleBackPressed(); activity.handleBackPressed(); });
        long disconnectStart = SystemClock.elapsedRealtime();
        end = disconnectStart + 60000;
        while ((!activity.isDestroyed() || !GlobalApp.getSessions().isEmpty()) && SystemClock.elapsedRealtime() < end) SystemClock.sleep(100);
        require(activity.isDestroyed() && GlobalApp.getSessions().isEmpty(), "clean disconnect and activity destruction");
        proof.append("clean disconnect: double-back action, activity destroyed, zero native sessions, elapsedMs=" + (SystemClock.elapsedRealtime() - disconnectStart) + "\n");
    }
}
