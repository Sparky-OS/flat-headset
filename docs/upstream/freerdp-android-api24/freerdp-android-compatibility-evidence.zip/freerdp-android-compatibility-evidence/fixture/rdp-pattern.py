import tkinter as tk
import time
root = tk.Tk()
root.overrideredirect(True)
root.geometry('2400x1080+0+0')
canvas = tk.Canvas(root, width=2400, height=1080, highlightthickness=0)
canvas.pack()
left = canvas.create_rectangle(0, 0, 1200, 1080, fill='#006020', outline='')
right = canvas.create_rectangle(1200, 0, 2400, 1080, fill='#0060e0', outline='')
canvas.create_text(600, 540, text='LEFT\nRDP API compatibility proof', fill='white', font=('Sans', 48), justify='center')
canvas.create_text(1800, 540, text='RIGHT\nRDP API compatibility proof', fill='white', font=('Sans', 48), justify='center')
sequence = 0
def frame():
    global sequence
    sequence += 1
    red = (sequence % 15) * 16
    canvas.itemconfigure(left, fill=f'#{red:02x}6020')
    canvas.itemconfigure(right, fill=f'#{red:02x}60e0')
    print(f'frame={sequence} marker={sequence % 15} monotonic={time.monotonic()}', flush=True)
    root.after(400, frame)
root.after(100, frame)
root.mainloop()
