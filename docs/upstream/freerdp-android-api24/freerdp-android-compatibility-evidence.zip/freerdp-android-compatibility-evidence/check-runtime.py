from pathlib import Path
import re
root=Path(__file__).resolve().parent / 'runtime'
for variant, apis in [('master',[24,28,29]),('candidate',[24,28,29])]:
    for api in apis:
        folder=root/f'{variant}-api{api}'
        if variant=='master' and api<29:
            text=(folder/'startup-logcat.txt').read_text()
            assert 'NoSuchMethodError' in text and 'FileObserver' in text, (variant,api)
            assert 'PASS:' not in (folder/'startup.txt').read_text()
            print(variant,api,'RED: actual Application/FileObserver API 29 constructor')
        else:
            for mode in ['startup','print','save','parcel','input','session']:
                text=(folder/f'{mode}.txt').read_text()
                assert 'PASS:' in text and 'INSTRUMENTATION_CODE: -1' in text,(variant,api,mode,text)
            session=(folder/'session-logcat.txt').read_text()
            server=(root/f'{variant}-api{api}-server.log').read_text()
            assert 'DisconnectProviderUltimatum' in session and 'rn-user-requested' in session
            assert 'DisconnectProviderUltimatum' in server and 'reason: 3' in server
            assert (folder/'session-proof.png').stat().st_size>1000
            print(variant,api,'GREEN: Application, print, persisted bookmark, parcel, real frames, clean disconnect')
for api in [24,28,29]:
    old=(root/'master-api29/parcel.txt').read_text()
    new=(root/f'candidate-api{api}/parcel.txt').read_text()
    assert re.findall(r'sha256=([0-9a-f]+)',old)==re.findall(r'sha256=([0-9a-f]+)',new),api
print('Parcel bytes match API 29 baseline across all candidate APIs')

for api, method in [(24, "getScaledHorizontalScrollFactor"), (28, "getClassification")]:
    result=(root/f"four-api{api}/input.txt").read_text()
    assert "NoSuchMethodError" in result and method in result and "PASS:" not in result
    print("four-commit input negative", api, method)
