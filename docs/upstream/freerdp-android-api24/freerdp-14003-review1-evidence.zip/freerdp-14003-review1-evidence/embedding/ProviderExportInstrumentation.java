/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only OR LicenseRef-KDE-Accepted-GPL */
package org.kde.kdeconnect;
import android.app.*;
import android.content.*;
import android.os.*;
import com.freerdp.freerdpcore.domain.BookmarkBase;
import java.io.*;
import java.lang.reflect.*;
import java.util.concurrent.*;
public class ProviderExportInstrumentation extends Instrumentation {
    private final StringBuilder proof = new StringBuilder();
    private final CountDownLatch created = new CountDownLatch(1);
    private void require(boolean value, String message) { if (!value) throw new AssertionError(message); }
    @Override public void onCreate(Bundle args) { super.onCreate(args); start(); }
    @Override public void callApplicationOnCreate(Application app) { super.callApplicationOnCreate(app); created.countDown(); }
    @Override public void onStart() {
        Bundle result = new Bundle();
        try {
            require(created.await(30, TimeUnit.SECONDS), "real Application startup");
            require(getTargetContext().getApplicationContext() instanceof KdeConnect, "real KdeConnect Application");
            checkExport();
            result.putString("stream", proof + "PASS: Flat Headset production HomeActivity export API " + Build.VERSION.SDK_INT + "\n");
            finish(Activity.RESULT_OK, result);
        } catch (Throwable error) {
            StringWriter trace=new StringWriter();error.printStackTrace(new PrintWriter(trace));
            result.putString("stream",proof+trace.toString());finish(Activity.RESULT_CANCELED,result);
        }
    }
    private static class ExportProbe extends com.freerdp.freerdpcore.presentation.HomeActivity {
        Intent chooser;
        ExportProbe(Context ctx) { attachBaseContext(ctx); }
        @Override public void startActivity(Intent intent) { chooser = intent; }
    }
    private void checkExport() throws Exception {
        java.util.concurrent.atomic.AtomicReference<Throwable> failure = new java.util.concurrent.atomic.AtomicReference<>();
        runOnMainSync(() -> {
            try {
                ExportProbe activity = new ExportProbe(getTargetContext());
                BookmarkBase bookmark = new BookmarkBase();
                bookmark.setLabel("provider proof"); bookmark.setHostname("192.0.2.1");
                Method method = com.freerdp.freerdpcore.presentation.HomeActivity.class.getDeclaredMethod("shareRdpFile", BookmarkBase.class);
                method.setAccessible(true); method.invoke(activity, bookmark);
                require(activity.chooser != null && Intent.ACTION_CHOOSER.equals(activity.chooser.getAction()), "export chooser");
                Intent share = activity.chooser.getParcelableExtra(Intent.EXTRA_INTENT);
                android.net.Uri uri = share.getParcelableExtra(Intent.EXTRA_STREAM);
                checkProviderUri(uri);
                require(Intent.ACTION_SEND.equals(share.getAction()) && "application/x-rdp".equals(share.getType()), "share intent");
                require((share.getFlags() & Intent.FLAG_GRANT_READ_URI_PERMISSION) != 0, "read grant");
                try (InputStream in = getTargetContext().getContentResolver().openInputStream(uri)) {
                    ByteArrayOutputStream out = new ByteArrayOutputStream(); byte[] buffer = new byte[4096]; int n;
                    while ((n = in.read(buffer)) != -1) out.write(buffer,0,n);
                    require(out.toString("UTF-8").contains("192.0.2.1"), "export contents");
                }
                new File(getTargetContext().getCacheDir(), "provider proof.rdp").delete();
                proof.append("export: production HomeActivity.shareRdpFile, chooser URI=" + uri + "; content readable\n");
            } catch (Throwable error) { failure.set(error); }
        });
        if (failure.get() != null) throw new AssertionError("export authority", failure.get());
    }
    private void checkProviderUri(android.net.Uri uri) {
        String authority = getTargetContext().getPackageName() + ".fileprovider";
        require(authority.equals(uri.getAuthority()), "host authority: " + uri);
        android.content.pm.ProviderInfo provider = getTargetContext().getPackageManager().resolveContentProvider(authority, 0);
        require(provider != null && provider.packageName.equals(getTargetContext().getPackageName()) && !provider.exported && provider.grantUriPermissions, "installed provider identity and grants");
    }
}
