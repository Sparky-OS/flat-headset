# FreeRDP Android compatibility, PR 14003 review revision

This attachment accompanies the revision requested by Armin Novak and İbrahim Sevinç.
The review fixes are folded into the print and Parcel commits of the five-commit series.
The source base is 0ac85f0cd7732de2a4407262ddd0919afd139814.

The existing AndroidX core 1.19.0 supplies ParcelCompat.
Its writeBoolean uses a 1/0 int before API29 and delegates to Parcel.writeBoolean on API29 and later; readBoolean uses readInt() != 0.
Android 10's Parcel.writeBoolean uses the same 1/0 int.
The runtime oracle compares both complementary patterns of the 20 bookmark flags against the saved, unmodified API29 master control from the original contribution.

HomeActivity derives the FileProvider authority from getPackageName(), and aFreeRDP's manifest uses ${applicationId}.fileprovider.
The provider visibility and URI-grant settings are unchanged.
The debug harness checks production print notification delivery, resolves the installed provider and opens its PDF URI.
Its export mode invokes the production HomeActivity.shareRdpFile method and intercepts the outgoing chooser intent to check its URI, grant and exported file contents.
The export probe does not qualify the standalone HomeActivity external-display launcher on API24.

## Reproduction

Apply series.patch to the base revision with git am.
Use JDK17, SDK37, Build Tools37.0.0, NDK29.0.13113456 and CMake4.1.2.
Copy release.properties into client/Android/Studio for the explicit embedding experiment: MIN_API=24, TARGET_API=28 and x86_64.
The upstream defaults are unchanged.
Point HARNESS_DIR at this directory and PUBLIC_DEBUG_KEY at Flat Headset's documented public android/debug.keystore.

```
./gradlew --no-daemon --max-workers=2 -I "$HARNESS_DIR/harness.gradle" :freeRDPCore:assembleDebug :aFreeRDP:assembleDebug
```

Each commit is also applied alone to the base and built, excluding only the two native configure/build CMake tasks after the unchanged native sources have already been built.
Full baseline and combined-candidate builds include native code.
The unit-test task has no source tests; passing instrumentation assertions are recorded separately.

Use fresh headless x86_64 emulators at API24, API28 and API29, KVM and SwiftShader, 2400x1080 at density320, two cores, 2048MB memory and no snapshots.
API24 additionally disables GLDMA.
Keep SDK files read-only and use a separate writable AVD directory per case.
Install with adb install --no-streaming; grant READ_EXTERNAL_STORAGE and WRITE_EXTERNAL_STORAGE and create /sdcard/Download.
Run startup, print, save, parcel, input, export and session in that order, force-stopping the process between modes.

```
adb shell am force-stop com.freerdp.afreerdp
adb shell am instrument -w -r -e mode startup com.freerdp.afreerdp/com.freerdp.afreerdp.proof.CompatibilityInstrumentation
```

Save also needs `-e server SERVER_IP` for the isolated RDP fixture.
The fixture is FreeRDP shadow server with a synthetic 2400x1080 Xvfb desktop, paired colored markers and a changing red channel, available in fixture/.
The fixture and emulator share only an internal Docker network, with no published ports or external route.
A pass requires PASS and INSTRUMENTATION_CODE: -1, not just adb exit zero.
Clean disconnect requires Activity destruction, zero native sessions and agreement with the server's user-requested disconnect.

Flat Headset embedding checks use the actual KdeConnect Application and its production FreeRDP print observer, with a debug-only assertion that the host-specific PDF URI is readable.
Its normal targetSdk35 and requestLegacyExternalStorage declaration are retained.
The debug export fixture declares a cache-path, as the production HomeActivity export writes a cache file and an embedding host must explicitly allow that path.
That debug-only path declaration is not a proposed change to Flat Headset production resources.
No Flat Headset stereo rendering, HEVC negotiation, ARM device or physical phone claim is made by this review revision.
The saved Flat Headset source delta and harness identify exactly what is used for this experiment.

## Results

All five commits build alone; the full current-master and combined-candidate native/Java builds pass.
Formatter14.0.6 and upstream codespell2.4.1 pass; NewApi lint retains the previously documented standalone external-display launcher finding.

| Case | API24 | API28 | API29 |
|---|---|---|---|
| Current master | FileObserver Application crash | FileObserver Application crash | seven modes pass |
| Revised upstream candidate | seven modes pass | seven modes pass | seven modes pass |
| Actual Flat Headset embedding | startup, print and export pass | startup, print and export pass | startup, print and export pass |
| Flat Headset old-authority control | not run | export fails resolving com.freerdp.afreerdp.fileprovider | not run |

Every positive Parcel comparison equals the original API29 control for both complementary 20-flag patterns.
All four positive RDP captures pass paired-marker pixel checks and were visually inspected.
Clean disconnect times: current-master/API29 6122ms; candidate/API24 902ms, API28 4249ms and API29 12011ms, within the existing 60-second ceiling.
The built aFreeRDP FileProvider authority remains com.freerdp.afreerdp.fileprovider; Flat Headset has org.kde.kdeconnect_tp.debug.fileprovider.
Certificates match the repository's public debug key; APK hashes and manifest dumps are included, but APKs and signing keys are not included in this attachment.

Run `python3 check-results.py` against the saved evidence.
The helper source is retained under checks/ for reading; only harness/ is included as the instrumentation Java source directory.
The Flat Headset embedding control changes the authority expression back to the previous string and otherwise uses the same harness and provider-path fixture.
All 13 native libraries are byte-identical, classes2.dex differs, and the generated license report's timestamp changes.
The relevant PrintJobMonitor, PrintNotificationHelper and candidate HomeActivity source files match upstream byte for byte.

The initial full master Gradle build succeeded, but a live edit to its shell wrapper broke its exit-status bookkeeping afterward.
That failure is retained; the corrected wrapper retry reuses the completed native outputs and passes.
The earlier missing-image failure is also retained as infrastructure history, not as a source regression.
The complete final runtime checker exits zero.

Published-series Jenkins PullRequestTester18511 passed all six subbuilds, including Android18513; it does not qualify this unpushed revision.
The remaining standalone launcher NewApi call, ARM/physical devices, stereo GL rendering and HEVC negotiation are outside this review proof.

