from pathlib import Path
import re, json
root=Path(__file__).resolve().parent / 'runtime'
old=(Path(__file__).resolve().parent / 'control/original-master-api29-parcel.txt').read_text()
for variant in ['master','candidate']:
 for api in [24,28,29]:
  case=root/f'{variant}-api{api}'
  if variant=='master' and api<29:
   log=(case/'startup-logcat.txt').read_text()
   assert 'NoSuchMethodError' in log and 'FileObserver' in log
   assert 'PASS:' not in (case/'startup.txt').read_text()
   print(variant,api,'RED: real Application FileObserver startup')
   continue
  for mode in ['startup','print','save','parcel','input','export','session']:
   text=(case/f'{mode}.txt').read_text()
   assert 'PASS:' in text and 'INSTRUMENTATION_CODE: -1' in text,(variant,api,mode,text)
  current=(case/'parcel.txt').read_text()
  assert re.findall(r'sha256=([0-9a-f]+)',old)==re.findall(r'sha256=([0-9a-f]+)',current),(variant,api)
  for mode in ['print','export']:
   assert 'com.freerdp.afreerdp.fileprovider' in (case/f'{mode}.txt').read_text(),(variant,api,mode)
  assert 'reason: 3' in (root/f'{variant}-api{api}-server.log').read_text()
  assert 'rn-user-requested' in (case/'session-logcat.txt').read_text()
  print(variant,api,'GREEN: seven modes; Parcel bytes match original API29 master; authority and URI readable; clean disconnect')
for api in [24,28,29]:
 case=root/f'flat-api{api}'
 for mode in ['startup','print']:
  text=(case/f'{mode}.txt').read_text()
  assert 'PASS: real KdeConnect Application' in text and 'INSTRUMENTATION_CODE: -1' in text,(api,mode,text)
 export=(case/'export.txt').read_text()
 assert 'PASS: Flat Headset production HomeActivity export' in export and 'INSTRUMENTATION_CODE: -1' in export, (api,export)
 assert 'org.kde.kdeconnect_tp.debug.fileprovider' in export, api
 log=(case/'print-logcat.txt').read_text()
 assert 'authority=org.kde.kdeconnect_tp.debug.fileprovider PDF URI readable' in log,api
 assert 'FATAL EXCEPTION' not in log and 'E FileObserver:' not in log,api
 print('Flat Headset',api,'GREEN: real KdeConnect startup and production print delivery; own provider authority and readable PDF')

negative=(root/'flat-prereview-api28/export.txt').read_text()
assert 'PASS:' not in negative and 'IllegalArgumentException' in negative and 'com.freerdp.afreerdp.fileprovider' in negative,negative
print('Flat Headset pre-review authority API28 RED: production HomeActivity export cannot resolve hard-coded aFreeRDP authority')
