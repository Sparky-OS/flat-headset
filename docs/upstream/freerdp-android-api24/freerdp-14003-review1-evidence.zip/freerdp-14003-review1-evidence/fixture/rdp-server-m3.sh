#!/bin/bash
set -euo pipefail
export DISPLAY=:99
Xvfb :99 -screen 0 2400x1080x24 -nolisten tcp &
xpid=$!
trap 'kill "$xpid" ${pattern_pid:-} ${server_pid:-} 2>/dev/null || true; wait || true' EXIT
for ((i=0;i<50;i++)); do xdpyinfo >/dev/null 2>&1 && break; sleep .1; done
python3 /proof/rdp-pattern-m3.py &
pattern_pid=$!
WLOG_LEVEL=TRACE stdbuf -oL -eL freerdp-shadow-cli3 /port:3389 /sec:rdp -auth +may-view +may-interact &
server_pid=$!
wait "$server_pid"
